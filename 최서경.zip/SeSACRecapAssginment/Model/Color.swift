//
//  Color.swift
//  SeSACRecapAssginment
//
//  Created by 최서경 on 1/18/24.
//

import Foundation

enum Color: String {
    case PointColor
}
