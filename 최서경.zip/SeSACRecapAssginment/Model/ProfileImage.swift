//
//  ProfileImage.swift
//  SeSACRecapAssginment
//
//  Created by 최서경 on 1/18/24.
//

import Foundation

enum ProfileImage: String, CaseIterable{
    case profile1
    case profile2
    case profile3
    case profile4
    case profile5
    case profile6
    case profile7
    case profile8
    case profile9
    case profile10
    case profile11
    case profile12
    case profile13
    case profile14

}
