//
//  SearchDetailViewController.swift
//  SeSACRecapAssginment
//
//  Created by 최서경 on 1/21/24.
//

import UIKit
import WebKit

class SearchDetailViewController: UIViewController {

     var urlString: String = "url"
     var userFind: String = ""
     
     @IBOutlet var webView: WKWebView!
     
     override func viewDidLoad() {
         super.viewDidLoad()
         
         if let url = URL(string: urlString) {
             let request = URLRequest(url: url)
             
             webView.load(request)
             navigationItem.title = userFind
         }

     }
}
