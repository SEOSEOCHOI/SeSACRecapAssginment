//
//  SettingProfileTableViewCell.swift
//  SeSACRecapAssginment
//
//  Created by 최서경 on 1/21/24.
//

import UIKit

class SettingProfileTableViewCell: UITableViewCell {
    @IBOutlet var userProfileImageView: UIImageView!
    @IBOutlet var uesrNameLabel: UILabel!
    @IBOutlet var userLikesCountLabel: UILabel!
    @IBOutlet var userStatusLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
