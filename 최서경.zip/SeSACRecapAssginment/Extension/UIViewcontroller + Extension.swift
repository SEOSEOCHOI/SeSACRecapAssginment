//
//  UIViewcontroller + Extension.swift
//  SeSACRecapAssginment
//
//  Created by 최서경 on 1/18/24.
//

import UIKit

extension UIViewController {
    func setBackgroundColor() {
        view.backgroundColor = .black
    }
}
